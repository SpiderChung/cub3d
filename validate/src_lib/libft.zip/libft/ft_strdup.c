/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kthucydi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/08 13:07:19 by kthucydi          #+#    #+#             */
/*   Updated: 2021/10/15 15:16:19 by kthucydi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "libft.h"

char	*ft_strdup(const char *src)
{
	char	*dest;
	int		cnt;

	cnt = 0;
	while (*(src + cnt))
		cnt++;
	dest = malloc(sizeof(*src) * (cnt + 1));
	if (dest == NULL)
		return (NULL);
	cnt = 0;
	while (*(src + cnt))
	{
		*(dest + cnt) = *(char *)(src + cnt);
		cnt++;
	}
	*(dest + cnt) = '\0';
	return (dest);
}
